


def py_typeof(anObject):
    __pragma__("js","{}","""
    var aType = typeof anObject;
    if (aType == 'object') {    // Directly trying '__class__ in anObject' turns out to wreck anObject in Chrome if its a primitive
        try {
            
            
            if(Object.keys(anObject).indexOf("__class__") >= 0 && anObject.__class__!=null){
                return anObject.__class__;
            }
            else{
                return object;
            }

            return dict;
        }
        catch (exception) {
            console.log(exception);
            return aType;
        }
    }
    else {
        return (    // Odly, the braces are required here
            aType == 'boolean' ? bool :
            aType == 'string' ? str :
            aType == 'number' ? (anObject % 1 == 0 ? int : float) :
            null
        );
    }
    
    """)


def list(iterable):   
    if iterable.__class__!=None and iterable.__class__.__name__ =="list":
        return iterable
    __pragma__("js","{}","""

    if (typeof(iterable)=="object"){
        return Object.keys(iterable);
    }
    else{
        var instance = iterable ? [] .slice.apply (iterable) : [];  // Spread iterable, n.b. array.slice (), so array before dot
        // Sort is the normal JavaScript sort, Python sort is a non-member function
        return instance;
    }

    """)



