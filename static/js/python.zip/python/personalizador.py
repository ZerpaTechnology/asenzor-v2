__pragma__("alias","s","$")
__pragma__("xpath",["","../../../Components"])


from SidebarCustomize import SidebarCustomize
from Media import Media
media=Media()


sidebar=SidebarCustomize()
sidebar.media=media

media.run(s("footer"))
sidebar.run(s("sidebar"))


