	(function () {
		var __name__ = '__main__';
		var SidebarCustomize = __init__ (__world__.SidebarCustomize).SidebarCustomize;
		var Media = __init__ (__world__.Media).Media;
		var media = Media ();
		var sidebar = SidebarCustomize ();
		sidebar.media = media;
		media.run ($ ('footer'));
		sidebar.run ($ ('sidebar'));
		__pragma__ ('<use>' +
			'Media' +
			'SidebarCustomize' +
		'</use>')
		__pragma__ ('<all>')
			__all__.Media = Media;
			__all__.SidebarCustomize = SidebarCustomize;
			__all__.__name__ = __name__;
			__all__.media = media;
			__all__.sidebar = sidebar;
		__pragma__ ('</all>')
	}) ();
